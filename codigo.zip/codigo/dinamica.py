class Dinamica:
    
    #from almacen import Almacen

    def __init__(self, Al):
        self.alm = Al
        
        
    def dinamica(self):
        self.tiempoA = 1
        self.tiempoB = 1
        self.tiempoAuxA = 0
        self.tiempoAuxB = 0
        self.caminoA = []
        self.caminoB = []
        self.depot = (0,self.alm.filas+1)
        self.posicionA = (0,self.alm.filas+1)
        self.posicionB = (0,self.alm.filas+1)
        self.caminoA.append(self.posicionA)
        self.caminoB.append(self.posicionB)

        self.pasillosConItems()
        
        self.recorrerSuperior()
        #print(self.camino)
        
        self.recorrerInferior()
        
        #print(self.camino)
        
        
    ####################
    # BLOQUE  SUPERIOR #
    ####################              
            
    def recorrerSuperior(self):
        izquierda = 0
        derecha = 0
        auxIzq = 1
        auxDer = 1

        for i in self.pasillosArriba:
            if i[0] == 1:
                if izquierda == 0:
                    izquierda = auxIzq
                derecha = auxDer
            auxIzq += 3
            auxDer += 3

        self.superiorIzquierda(izquierda)

        auxIzq = (izquierda - 1) / 3
        auxDer = (derecha - 1) / 3
        pasillo = auxIzq + 1
        
        while(pasillo < auxDer):
            
            if self.pasillosArriba[int(pasillo)][0] == 0:
            
                for i in range(0,3):
                    self.posicionA = (self.posicionA[0]+1, self.posicionA[1])
                    self.caminoA.append(self.posicionA)
                    self.tiempoA += 1
                    
                    self.posicionB = (self.posicionB[0]+1, self.posicionB[1])
                    self.caminoB.append(self.posicionB)
                    self.tiempoB += 1
                    
            else:
                self.copiaCaminoA = self.caminoA.copy()
                self.superiorIntermedioA(pasillo)
                self.superiorIntermedioB(pasillo)
                self.posicionA = (self.posicionA[0]+3, self.posicionA[1])
                self.posicionB = (self.posicionB[0]+3, self.posicionB[1])
                self.tiempoA = self.tiempoAuxA
                
            pasillo += 1

        if auxIzq != auxDer:
            self.superiorDerecha(pasillo)
        
        elif auxIzq == auxDer:
            for i in range(0, self.alm.filas+1):
                self.posicionA = (self.posicionA[0], self.posicionA[1]+1)
                self.caminoA.append(self.posicionA)
                self.tiempoA += 1
            
        if self.tiempoA < self.tiempoB:
            self.tiempoB = self.tiempoA
            self.caminoB = self.caminoA.copy()           
            self.tiempo = self.tiempoA
            self.camino = self.caminoA.copy()

        else:
            self.tiempoA = self.tiempoB
            self.caminoA = self.caminoB.copy()           
            self.tiempo = self.tiempoB
            self.camino = self.caminoB.copy()
            
    
    # Método para crear los caminos A y B empezando en el depot
    
    def superiorIzquierda(self,izq):
        
        aux = int((izq - 1) / 3)
        
        while (self.posicionA[0] < izq):
            self.posicionA = (self.posicionA[0]+1, self.posicionA[1])
            self.caminoA.append(self.posicionA)
            self.tiempoA += 1
            self.posicionB = (self.posicionB[0]+1, self.posicionB[1])
            self.caminoB.append(self.posicionB)
            self.tiempoB += 1
            
        for i in range(0, self.alm.filas+1):
            self.posicionA = (self.posicionA[0], self.posicionA[1]-1)
            self.caminoA.append(self.posicionA)
            self.tiempoA += 1

        hasta = self.pasillosArriba[aux][1]
        for i in range(1,hasta+1):
            self.posicionB = (self.posicionB[0], self.posicionB[1]-1)
            self.caminoB.append(self.posicionB)
            self.tiempoB += 1
        
        for i in range(1,hasta+1):
            self.posicionB = (self.posicionB[0], self.posicionB[1]+1)
            self.caminoB.append(self.posicionB)
            self.tiempoB += 1


    # Método para finalizar los caminos A y B del bloque superior y pasar al bloque inferior
    
    def superiorDerecha(self, der):

        hasta = self.pasillosArriba[int(der)][1]
        
        for i in range(0,3):
            self.posicionB = (self.posicionB[0]+1,self.posicionB[1])
            self.caminoB.append(self.posicionB)
            self.tiempoB += 1
    
        for i in range(1,hasta+1):
            self.posicionB = (self.posicionB[0], self.posicionB[1]-1)
            self.caminoB.append(self.posicionB)
            self.tiempoB += 1
        
        for i in range(1,hasta+1):
            self.posicionB = (self.posicionB[0], self.posicionB[1]+1)
            self.caminoB.append(self.posicionB)
            self.tiempoB += 1

        for i in range(0,3):
            self.posicionA = (self.posicionA[0]+1,self.posicionA[1])
            self.caminoA.append(self.posicionA)
            self.tiempoA += 1
            
        for i in range(0,self.alm.filas+1):
            self.posicionA = (self.posicionA[0], self.posicionA[1]+1)
            self.caminoA.append(self.posicionA)
            self.tiempoA += 1
            

    # Método para completar el camino A del bloque superior
    
    def superiorIntermedioA(self, p):
        
        hasta = self.alm.filas - self.pasillosArriba[int(p)][2] + 1
        
        auxA = 3 + self.tiempoA + (hasta * 2)
        auxB = 3 + self.tiempoB + self.alm.recorrerPasillo
        
        posAaux = self.posicionA
        posBaux = self.posicionB
        
        self.tiempoAuxA = self.tiempoA
        
        if auxB > auxA:
            
            for i in range(0,3):
                posAaux = (posAaux[0]+1,posAaux[1])
                self.caminoA.append(posAaux)
                self.tiempoAuxA += 1
            
            for i in range(0, hasta):
                posAaux = (posAaux[0],posAaux[1]+1)
                self.caminoA.append(posAaux)
                self.tiempoAuxA += 1
            
            for i in range(0, hasta):
                posAaux = (posAaux[0],posAaux[1]-1)
                self.caminoA.append(posAaux)
                self.tiempoAuxA += 1

        else:
            
            self.tiempoAuxA = self.tiempoB
            self.caminoA = self.caminoB.copy()
            
            for i in range(0,3):
                posBaux = (posBaux[0]+1,posBaux[1])
                self.caminoA.append(posBaux)
                self.tiempoAuxA += 1
            
            for i in range(0,self.alm.recorrerPasillo):
                posBaux = (posBaux[0],posBaux[1]-1)
                self.caminoA.append(posBaux)
                self.tiempoAuxA += 1
            
        
    # Método para completar el camino B del bloque superior
    
    def superiorIntermedioB(self, p):
        
        hasta = self.pasillosArriba[int(p)][1]
        
        auxA = 3 + self.tiempoA + self.alm.recorrerPasillo
        auxB = 3 + self.tiempoB + (hasta*2)
        
        posAaux = self.posicionA
        posBaux = self.posicionB
        
        if auxA > auxB:
            
            for i in range(0,3):
                posBaux = (posBaux[0]+1,posBaux[1])
                self.caminoB.append(posBaux)
                self.tiempoB += 1
            
            for i in range(0, hasta):
                posBaux = (posBaux[0],posBaux[1]-1)
                self.caminoB.append(posBaux)
                self.tiempoB += 1
            
            for i in range(0, hasta):
                posBaux = (posBaux[0],posBaux[1]+1)
                self.caminoB.append(posBaux)
                self.tiempoB += 1

        else:
            
            self.tiempoB = self.tiempoA
            self.caminoB = self.copiaCaminoA.copy()
                
            for i in range(0,3):
                posAaux = (posAaux[0]+1,posAaux[1])
                self.caminoB.append(posAaux)
                self.tiempoB += 1
                
            for i in range(0,self.alm.recorrerPasillo):
                posAaux = (posAaux[0],posAaux[1]+1)
                self.caminoB.append(posAaux)
                self.tiempoB += 1
                
                
                
    ####################
    # BLOQUE  INFERIOR #
    ####################                

    def recorrerInferior(self):
        
        izquierda = 0
        derecha = 0
        
        auxIzq = 1
        auxDer = 1

        for i in self.pasillosAbajo:
            if i[0] == 1:
                if izquierda == 0:
                    izquierda = auxIzq
                derecha = auxDer
            auxIzq += 3
            auxDer += 3
            
        self.inferiorDerecha(derecha)

        auxIzq = (izquierda - 1) / 3
        auxDer = (derecha - 1) / 3
        pasillo = auxDer - 1
        
        while(pasillo > auxIzq):
            
            if self.pasillosAbajo[int(pasillo)][0] == 0:
            
                for i in range(0,3):
                    self.posicionA = (self.posicionA[0]-1, self.posicionA[1])
                    self.caminoA.append(self.posicionA)
                    self.tiempoA += 1
                    
                    self.posicionB = (self.posicionB[0]-1, self.posicionB[1])
                    self.caminoB.append(self.posicionB)
                    self.tiempoB += 1
                    
            else:
                self.copiaCaminoA = self.caminoA.copy()
                self.inferiorIntermedioA(pasillo)
                self.inferiorIntermedioB(pasillo)
                self.posicionA = (self.posicionA[0]-3, self.posicionA[1])
                self.posicionB = (self.posicionB[0]-3, self.posicionB[1])
                self.tiempoA = self.tiempoAuxA
                
            pasillo -= 1
        
        if auxIzq != auxDer:
            self.inferiorIzquierda(pasillo)
            
        if self.tiempoA < self.tiempoB:
            self.tiempo = self.tiempoA
            self.camino = self.caminoA.copy()

        else:
            self.tiempo = self.tiempoB
            self.camino = self.caminoB.copy()
            
        while(self.depot != self.posicionA):
            self.posicionA = (self.posicionA[0]-1,self.posicionA[1])
            self.camino.append(self.posicionA)
            self.tiempo += 1
            
    
    # Método para seguir los caminos A y B desde la parte derecha del almacén
    
    def inferiorDerecha(self,der):
        
        aux = int((der - 1) / 3)

        while(der > self.posicionA[0]):
            self.posicionA = (self.posicionA[0]+1, self.posicionA[1])
            self.caminoA.append(self.posicionA)
            self.tiempoA += 1
            self.posicionB = (self.posicionB[0]+1, self.posicionB[1])
            self.caminoB.append(self.posicionB)
            self.tiempoB += 1
                
        while(der < self.posicionA[0]):
            self.posicionA = (self.posicionA[0]-1, self.posicionA[1])
            self.caminoA.append(self.posicionA)
            self.tiempoA += 1
            self.posicionB = (self.posicionB[0]-1, self.posicionB[1])
            self.caminoB.append(self.posicionB)
            self.tiempoB += 1
            
        hasta = self.alm.filas - self.pasillosAbajo[aux][2] + 1
        
        for i in range(0, hasta):
            self.posicionA = (self.posicionA[0], self.posicionA[1]+1)
            self.caminoA.append(self.posicionA)
            self.tiempoA += 1
        
        for i in range(0, hasta):
            self.posicionA = (self.posicionA[0], self.posicionA[1]-1)
            self.caminoA.append(self.posicionA)
            self.tiempoA += 1
        
        for i in range(0, self.alm.filas+1):
            self.posicionB = (self.posicionB[0], self.posicionB[1]+1)
            self.caminoB.append(self.posicionB)
            self.tiempoB += 1

    
    # Método para finalizar los caminos A y B del bloque inferior y llegar de vuelta al depot
    
    def inferiorIzquierda(self, izq):

        hasta = self.alm.filas - self.pasillosAbajo[int(izq)][2] + 1
        
        for i in range(0,3):
            self.posicionB = (self.posicionB[0]-1,self.posicionB[1])
            self.caminoB.append(self.posicionB)
            self.tiempoB += 1
    
        for i in range(0,self.alm.filas+1):
            self.posicionB = (self.posicionB[0], self.posicionB[1]-1)
            self.caminoB.append(self.posicionB)
            self.tiempoB += 1          
        
        for i in range(0,3):
            self.posicionA = (self.posicionA[0]-1,self.posicionA[1])
            self.caminoA.append(self.posicionA)
            self.tiempoA += 1
        
        for i in range(0,hasta):
            self.posicionA = (self.posicionA[0], self.posicionA[1]+1)
            self.caminoA.append(self.posicionA)
            self.tiempoA += 1
        
        for i in range(0,hasta):
            self.posicionA = (self.posicionA[0], self.posicionA[1]-1)
            self.caminoA.append(self.posicionA)
            self.tiempoA += 1            

            
    # Método para completar el camino A del bloque inferior
    
    def inferiorIntermedioA(self, p):
        
        hasta = self.alm.filas - self.pasillosAbajo[int(p)][2] + 1
        
        auxA = 3 + self.tiempoA + (hasta * 2)
        auxB = 3 + self.tiempoB + self.alm.recorrerPasillo
        
        posAaux = self.posicionA
        posBaux = self.posicionB
        
        self.tiempoAuxA = self.tiempoA
        
        if auxB > auxA:
            
            for i in range(0,3):
                posAaux = (posAaux[0]-1,posAaux[1])
                self.caminoA.append(posAaux)
                self.tiempoAuxA += 1
            
            for i in range(0, hasta):
                posAaux = (posAaux[0],posAaux[1]+1)
                self.caminoA.append(posAaux)
                self.tiempoAuxA += 1
            
            for i in range(0, hasta):
                posAaux = (posAaux[0],posAaux[1]-1)
                self.caminoA.append(posAaux)
                self.tiempoAuxA += 1

        else:
            
            self.tiempoAuxA = self.tiempoB
            self.caminoA = self.caminoB.copy()
            
            for i in range(0,3):
                posBaux = (posBaux[0]-1,posBaux[1])
                self.caminoA.append(posBaux)
                self.tiempoAuxA += 1
            
            for i in range(0,self.alm.recorrerPasillo):
                posBaux = (posBaux[0],posBaux[1]-1)
                self.caminoA.append(posBaux)
                self.tiempoAuxA += 1
            
        
    # Método para completar el camino B del bloque inferior
    
    def inferiorIntermedioB(self, p):
        
        hasta = self.pasillosAbajo[int(p)][1]
        
        auxA = 3 + self.tiempoA + self.alm.recorrerPasillo
        auxB = 3 + self.tiempoB + (hasta*2)
        
        posAaux = self.posicionA
        posBaux = self.posicionB
        
        if auxA > auxB:
            
            for i in range(0,3):
                posBaux = (posBaux[0]-1,posBaux[1])
                self.caminoB.append(posBaux)
                self.tiempoB += 1
            
            for i in range(0, hasta):
                posBaux = (posBaux[0],posBaux[1]-1)
                self.caminoB.append(posBaux)
                self.tiempoB += 1
            
            for i in range(0, hasta):
                posBaux = (posBaux[0],posBaux[1]+1)
                self.caminoB.append(posBaux)
                self.tiempoB += 1
                
        else:
            
            self.tiempoB = self.tiempoA
            self.caminoB = self.copiaCaminoA.copy()
                
            for i in range(0,3):
                posAaux = (posAaux[0]-1,posAaux[1])
                self.caminoB.append(posAaux)
                self.tiempoB += 1
                
            for i in range(0,self.alm.recorrerPasillo):
                posAaux = (posAaux[0],posAaux[1]+1)
                self.caminoB.append(posAaux)
                self.tiempoB += 1
                        
            
    # Método para crear 2 listas de listas, una para el bloque superior y otra para el inferior. 
    # Cada sublista incluye la informacion de un pasillo vertical: 
    #           0 si no hay ningún item a recoger, 1 si hay algún item a recoger 
    #           El producto más lejano al centro del almacén
    #           El producto más cercano al centro del almacén     
    
    def pasillosConItems(self):
        
        self.pasillosArriba = []
        self.pasillosAbajo = []

        posAux = (self.posicionA[0]+1, self.posicionA[1])
        
        while (posAux[0] < self.alm.pasillos*3 - 1):
            
            auxArr = False
            auxAba = False
                            
            listaAuxArr = []
            listaAuxAba = []
            
            mayorArr = 0
            menorArr = 0   
                
            mayorAba = 0
            menorAba = 0

            for j in range(1,self.alm.filas+1):
                
                if (self.alm.alm[posAux[1]-j][posAux[0]-1] > 1) or (self.alm.alm[posAux[1]-j][posAux[0]+1] > 1):
                    auxArr = True
                    if menorArr == 0:
                        menorArr = j
                    mayorArr = j

                if (self.alm.alm[posAux[1]+j][posAux[0]-1] > 1) or (self.alm.alm[posAux[1]+j][posAux[0]+1] > 1):
                    auxAba = True
                    if mayorAba == 0:
                        mayorAba = self.alm.filas + 1 - j
                    menorAba = self.alm.filas + 1 - j                        
            
            # Pasillo j vertical hacia arriba
            if auxArr == True:
                listaAuxArr.append(1)
            else:
                listaAuxArr.append(0)
            listaAuxArr.append(mayorArr)
            listaAuxArr.append(menorArr)
            self.pasillosArriba.append(listaAuxArr)
            
            # Pasillo j vertical hacia abajo
            if auxAba == True:
                listaAuxAba.append(1)
            else:
                listaAuxAba.append(0)
            listaAuxAba.append(mayorAba)
            listaAuxAba.append(menorAba)
            self.pasillosAbajo.append(listaAuxAba)
            
            posAux = (posAux[0]+3,posAux[1])