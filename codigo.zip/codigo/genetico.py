class Genetico:
    
    def __init__(self,almacen, s, mostrarSolu):
        from datetime import datetime
        self.almacen = almacen

        #Cambiar la semilla por s si se quieren obtener experimentos reproducibles
        #self.seed = s
        self.seed = datetime.now()
        
        self.mostrarSolu = mostrarSolu


        
    def genetico(self):
        
        self.tamPoblacion = 90
        self.iteraciones = 100
        self.probMutacion = 0.5
        self.torneo = int(self.tamPoblacion * 0.1)

        self.cap = self.almacen.capacidad
        self.poblacionActual = {}
        self.tiempoIndividuos = {}
        self.listasPedidos = {}
        self.rutasCalculadas = {}

        self.iteracion = 0
        self.poblacionActual = self.crearPoblacionInicial()
        self.evaluarFitnessHash()

        #Mostrar el print de abajo para ver los resultados de la primera iteración del algoritmo genético        
        #print("Generacion",self.iteracion,":","Mejor:",min(self.fitness),"Peor:",max(self.fitness))

        self.acabar = 0
        self.mejorAux = min(self.fitness)
        while(self.acabar < 20 or self.iteracion < self.iteraciones):
            self.iteracion += 1
            self.seleccion()
            self.cruce()
            self.evaluarFitnessHash()
            self.actualizarPoblacion()
            if(self.mejorAux == min(self.fitness)):
                self.acabar += 1
            else:
                self.acabar = 0
                self.mejorAux = min(self.fitness)

        if(self.mostrarSolu == 1):
            self.solucion()
        
        return min(self.fitness)
    
    

    # Método para crear la poblaciçon inicial del algoritmo genético
    def crearPoblacionInicial(self):
        
        import random
        random.seed(self.seed)

        p = self.almacen.numPedidos
        lista = range(0,p)
        poblacionInicial = {}
        
        for ind in range(0,self.tamPoblacion):
            individuo = [[0,[]]]
            rndm = random.sample(lista,p)
            self.listasPedidos[ind] = rndm
            for i in rndm:
                agregado = False
                cantidadProductos = self.almacen.pedidosInfo.get(i)
                aux = 0
                while aux < len(individuo):
                    if (cantidadProductos + individuo[aux][0]) < self.cap:
                        individuo[aux][0] += cantidadProductos
                        individuo[aux][1].append(i)
                        aux = len(individuo)
                        agregado = True
                    aux += 1
                if agregado == False:
                    individuo.append([cantidadProductos,[i]])
            poblacionInicial[ind] = individuo
                
        return poblacionInicial    
    

    
    # Método para llevar acabo la selección de los individuos de la siguiente población
    def seleccion(self):
        
        import random
        random.seed(self.seed)

        copiaPoblacion = {}
        copiaTiempos = {}
        copiaListas = {}


        # En mejorIndividuo guardamos el mejor individuo de la poblacion
        menorAux = 10000000
        for x in range(0,self.tamPoblacion):
            if self.tiempoIndividuos[x] < menorAux:
                menorAux = self.tiempoIndividuos[x]
                self.mejorIndividuo = [self.poblacionActual[x], self.tiempoIndividuos[x], self.listasPedidos[x]]

        # Seleccionamos los individuos de la nueva poblacion por torneo
        for i in range(0,self.tamPoblacion):
            elegidos = []
            menor = 10000000
            menorInd = -1
            for j in range(0,self.torneo):
                elegidos.append(random.randint(0,self.tamPoblacion-1))

            for k in elegidos:
                if (self.tiempoIndividuos.get(k) < menor):
                    menor = self.tiempoIndividuos.get(k)
                    menorInd = k

            copiaPoblacion[i] = self.poblacionActual[menorInd]
            copiaTiempos[i] = self.tiempoIndividuos[menorInd] 
            copiaListas[i] = self.listasPedidos[menorInd]

        self.poblacionActual = copiaPoblacion.copy()
        self.tiempoIndividuos = copiaTiempos.copy()
        self.listasPedidos = copiaListas.copy()
    

    
    # Método para la función de cruce y crear dos hijos a partir de cada par de padres
    def cruce(self):

        import random
        random.seed(self.seed)

        hijos = {}
        aux = 0
        while (aux < self.tamPoblacion):
            padre1 = self.listasPedidos[aux].copy()
            padre2 = self.listasPedidos[aux+1].copy()
            mitad = int(len(padre1)/2)
            hijo1 = padre1[0:mitad]
            hijo2 = padre2[0:mitad]

            pedido = 0
            while(len(hijo1) < len(padre1)):
                if (padre2[pedido] not in hijo1):
                    hijo1.append(padre2[pedido])
                pedido += 1

            # El 20% de los individuos mutan
            rdmAux = random.uniform(0,1)
            if rdmAux < self.probMutacion:
                hijo1 = self.mutacion(hijo1)
            
            self.listasPedidos[aux] = hijo1.copy()
            hijos[aux] = self.crearPoblacion(hijo1)
            aux += 1

            pedido = 0
            while(len(hijo2) < len(padre1)):
                if (padre1[pedido] not in hijo2):
                    hijo2.append(padre1[pedido])
                pedido += 1

                
            # El 20% de los individuos mutan
            rdmAux = random.uniform(0,1)
            if rdmAux < self.probMutacion:
                hijo2 = self.mutacion(hijo2)

            self.listasPedidos[aux] = hijo2.copy()
            hijos[aux] = self.crearPoblacion(hijo2)
            aux += 1

        self.poblacionActual = hijos.copy()
    
    

    # Método para la función de mutación
    def mutacion(self, lista):

        import random
        random.seed(self.seed)
        # Mutación intercambiando pedidos aleatorios: 1
        # Mutación seleccionando un fragmento de la lista e invirtiéndolo: 2
        # Modificar el valor de abajo a 1 o 2 según se quiera una mutación u otra
        self.tipoMutacion = 2

        if(self.tipoMutacion == 1):
            copia = lista.copy()
            mutar = random.randint(1,int((self.almacen.numPedidos)*0.2))
            for i in range(0,mutar):
                a = random.randint(0,len(lista)-1)
                b = random.randint(0,len(lista)-1)
                aux = copia[a]
                copia[a] = copia[b]
                copia[b] = aux
            return copia

        elif(self.tipoMutacion == 2):
            
            copia = lista.copy()
            punto = random.randint(0,len(copia))
            hasta = random.randint(2,len(copia))
            aux = copia[punto:(punto+hasta)]
            aux.reverse()            
            mutada = copia[0:punto] + aux + copia[(punto+hasta):(len(copia))]
            return mutada



    # Método para crear la población a partir de los pedidos
    def crearPoblacion(self, pedidos):

        hijo = [[0,[]]]
        for i in pedidos:
            agregado = False
            cantidadProductos = self.almacen.pedidosInfo.get(i)
            aux = 0
            while aux < len(hijo):
                if (cantidadProductos + hijo[aux][0]) < self.cap:
                    hijo[aux][0] += cantidadProductos
                    hijo[aux][1].append(i)
                    aux = len(hijo)
                    agregado = True
                aux += 1
            if agregado == False:
                hijo.append([cantidadProductos,[i]])
        
        return hijo     


        
    # Evaluar fitness con programación dinámica
    def evaluarFitness(self):
        
        from dinamica import Dinamica
        import copy
        dinam = Dinamica(self.almacen)
        self.fitness = []

        for i in range(0,self.tamPoblacion):
            tiempo = 0

            for j in range(0,len(self.poblacionActual[i])):
                
                ruta = copy.deepcopy(self.almacen.vacio)                
                aux = self.poblacionActual[i][j][1]

                for k in range(0,len(aux)):
                    coordenadas = self.almacen.coordenadasPedidos[self.poblacionActual[i][j][1][k]]
                    for c in coordenadas:
                        ruta[c[0]][c[1]] = 2
                dinam.alm.alm = copy.deepcopy(ruta)
                dinam.dinamica()
                tiempo += dinam.tiempo

            self.fitness.append(tiempo)
            self.tiempoIndividuos[i] = tiempo

        

    # Evaluar fitness con diccionario para ahorrar tiempo
    def evaluarFitnessHash(self):
        
        from dinamica import Dinamica
        import copy
        dinam = Dinamica(self.almacen)
        self.fitness = []

        
        for i in range(0,self.tamPoblacion):
            tiempo = 0

            for j in range(0,len(self.poblacionActual[i])):
                
                ruta = copy.deepcopy(self.almacen.vacio)

                aux = self.poblacionActual[i][j][1].copy()
                
                #ordenado = aux.copy().sort()
                ordenado = sorted(aux)
                strings = [str(numero) for numero in ordenado]
                numerosString = "".join(strings)
                
                # Diccionario para guardar la información de las rutas ya calculadas y ahorrar tiempo
                if (numerosString not in self.rutasCalculadas.keys()):
                    for k in range(0,len(aux)):
                        coordenadas = self.almacen.coordenadasPedidos[self.poblacionActual[i][j][1][k]]
                        for c in coordenadas:
                            ruta[c[0]][c[1]] = 2
                    dinam.alm.alm = copy.deepcopy(ruta)
                    dinam.dinamica()
                    tiempo += dinam.tiempo
                    self.rutasCalculadas[numerosString] = dinam.tiempo

                else:
                    tiempo += self.rutasCalculadas.get(numerosString)


            self.fitness.append(tiempo)
            self.tiempoIndividuos[i] = tiempo


    # Método para actualizar la población a la nueva tras el cruce, la mutación y la selección
    def actualizarPoblacion(self):
        
        mayorAux = 0
        for y in range(0,self.tamPoblacion):
            if self.tiempoIndividuos.get(y) > mayorAux:
                mayorAux = self.tiempoIndividuos.get(y)
                peorIndividuo = y

        self.poblacionActual[peorIndividuo] = self.mejorIndividuo[0]
        self.tiempoIndividuos[peorIndividuo] = self.mejorIndividuo[1]
        self.listasPedidos[peorIndividuo] = self.mejorIndividuo[2]
        self.fitness[peorIndividuo] = self.mejorIndividuo[1]

        #Mostrar el print de abajo para ver los resultados de cada iteración del algoritmo genético        
        #print("Generacion",self.iteracion,":","Mejor:",min(self.fitness),"Peor:",max(self.fitness))
        


    # Método que muestra de forma gráfica la solución, utilizando la interfaz implementada.
    def solucion(self):

        from dinamica import Dinamica
        import copy

        solucionMostrar = Dinamica(self.almacen)
        solucion = self.fitness.index(min(self.fitness))
        rutas = self.poblacionActual.get(solucion)
        #print(len(rutas))
        for i in range(0,len(rutas)):
            ruta = copy.deepcopy(self.almacen.vacio)
            for j in range(0,len(rutas[i][1])):
                coord = self.almacen.coordenadasPedidos[rutas[i][1][j]]
                for c in range(0,len(coord)):
                    ruta[coord[c][0]][coord[c][1]] = 2+c # cambiar colores segun pedido
            solucionMostrar.alm.alm = copy.deepcopy(ruta)
            solucionMostrar.dinamica()
            self.almacen.pedidosMostrar = rutas[i][1]
            self.almacen.crear(solucionMostrar.camino, i)
