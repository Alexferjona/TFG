class Almacen:
    
    
    def __init__(self, sett, pedi):
        
        self.txtAlmacen = sett
        self.txtPedidos = pedi
        self.pedidosMostrar = []
        
        
    def leerInstancia(self):
        
        setting = open(self.txtAlmacen)
        pasillos = setting.readline()
        filas = setting.readline()
                
        for i in range(0,len(pasillos)):
            if pasillos[i] == ':':
                aux = i
        self.pasillos = int(pasillos[aux+2:])
        
        for i in range(0,len(filas)):
            if filas[i] == ':':
                aux = i
        self.filas = int(int(filas[aux+2:])/2)
        self.recorrerPasillo =  self.filas + 1
        self.crearAlmacen()
        
        for i in range(0,11):
            setting.readline()
        
        pedidos = setting.readline()
        for i in range(0,len(pedidos)):
            if pedidos[i] == ':':
                self.numPedidos = int(pedidos[i+2:])
                
        for i in range(0,8):
            setting.readline()
        
        capacidad = setting.readline()
        for i in range(0,len(capacidad)):
            if capacidad[i] == ':':
                self.capacidad = int(capacidad[i+2:])
        

        
    def crearPedidos(self): 
        
        import random
        import copy

        self.pedidosInfo = {}
        self.coordenadasPedidos = []
        
        self.listaPedidos = []
        for i in range(0,self.numPedidos):
            self.listaPedidos.append(copy.deepcopy(self.alm))
            
        pedidos = open(self.txtPedidos)
        
        for i in range(0,self.numPedidos):
            
            coordenadasPedido = []
            linea = pedidos.readline()
            
            for l in range(0,len(linea)):
                if linea[l] == 's':
                    aux = l
            
            productos = int(linea[aux+2:])
            self.pedidosInfo[i] = productos
            
            for k in range(0, productos):
                pedido = pedidos.readline()
                for j in range(0,len(pedido)):
                    if pedido[j] == 'e':
                        aux = int(pedido[j+2:j+4])

                        pasillo = int((aux + 1) / 2) + aux
                        
                    elif pedido[j] == 'n':
                        aux = int(pedido[j+2:])
                        if aux > ((self.filas*2)-1):
                            aux = self.filas*2 - 1
                        if aux < self.filas:
                            fila = aux+1
                        else:
                            fila = aux+2
                coordenadasPedido.append((fila,pasillo))
                self.listaPedidos[i][fila][pasillo] = 2
            self.coordenadasPedidos.append(coordenadasPedido)
            


    def crearAlmacen(self):

        import copy

        almacen = []
        vacia = [0] * (self.pasillos * 3)
        almacen.append(vacia) 
        for i in range (0,2):
            for f in range (0,self.filas):
                fila = []
                fila.append(1)
                fila.append(0)
                for p in range (0,self.pasillos-1):
                    fila.append(1)
                    fila.append(1)
                    fila.append(0)
                fila.append(1)    
                almacen.append(fila)
            if i == 0:
                aux = [0] * (self.pasillos * 3)  
                aux[0] = -1
                almacen.append(aux)    
        almacen.append(vacia) 
        self.alm = almacen
        self.x = len(almacen)
        self.y = len(almacen[0])
        self.vacio = copy.deepcopy(self.alm)
        
        

    def crearPrimerPasillo(self):
        aux = []
        aux.append(0)
        for i in range(0,self.filas):
            aux.append(1)
        aux.append(-1)
        for i in range(0,self.filas):
            aux.append(1)
        aux.append(0)
        
        

    def dibujaCelda(self, tCelda, i, j, clr):
                
        x1 = tCelda * j
        y1 = tCelda * i
        self.auxX = i
        self.auxY = j
        x2 = x1 + tCelda
        y2 = y1 + tCelda
        self.interfaz.create_rectangle(x1, y1, x2, y2, fill=clr)
        
        

    def crear(self, camino, ruta):
        
        import tkinter as tk
        
        tamCelda = 20
        
        self.ventana = tk.Tk()
        nombre = "Ruta",ruta
        self.ventana.title(nombre)
        
        self.interfaz = tk.Canvas(self.ventana, width = tamCelda*self.y, height = tamCelda*self.x, bg = 'grey')
        self.interfaz.pack()
        
        for i in range(self.x):
            for j in range(self.y):
                celda = self.alm[i][j]
                if celda == 0:
                    color = 'dimgray'
                elif celda == 1:
                    color = 'White'
                elif celda == -1:
                    color = 'red'
                elif celda >= 2:
                    color = 'blue'
                self.dibujaCelda(tamCelda, i,j,color)
            
        self.camino = camino
        self.antiguo = 0
        self.nuevo = 1
        #boton = tk.Button(self.ventana, text="Dinámica",command=lambda:[self.mostrarRuta,self.mostrarPedidos])
        boton = tk.Button(self.ventana, text="Dinámica",command=self.mostrarRuta)
        boton.pack(side=tk.LEFT)
        boton = tk.Button(self.ventana, text="Siguiente",command=self.ventana.destroy)
        boton.pack(side=tk.LEFT)

        self.ventana.mainloop()
        
        

    def mostrarRuta(self):
        import time
        import tkinter as tk
        aux = self.camino[0]
        for i in self.camino:
            x = 20*aux[0]
            y = 20*aux[1]
            if i[0] > aux[0]:
                self.interfaz.create_line(x+2, y+7, x+20, y+7,arrow=tk.LAST,fill='cyan')
            elif i[0] < aux[0]:
                self.interfaz.create_line(x+18, y+13, x, y+13,arrow=tk.LAST,fill='cyan')
            elif i[1] > aux[1]:
                self.interfaz.create_line(x+13, y+2, x+13, y+20,arrow=tk.LAST,fill='cyan')
            elif i[1] < aux[1]:
                self.interfaz.create_line(x+7, y+18, x+7, y,arrow=tk.LAST,fill='cyan')
            aux = i

        texto2 = tk.Label(self.ventana, text=self.pedidosMostrar)
        texto2.pack(side=tk.RIGHT)
        texto = tk.Label(self.ventana, text="Pedidos:")
        texto.pack(side=tk.RIGHT)
        


    
        

            