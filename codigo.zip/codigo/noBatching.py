#Clase que no usa ningún algoritmo de batching, tan solo considera un individuo del cual se obtiene la solución.

class NoBatching:

    def __init__(self,almacen, s):
        self.almacen = almacen
        self.seed = s
        self.cap = self.almacen.capacidad


    # Creamos el individuo y calculamos su fitness
    def solucionNoBatching(self):
        self.crearIndividuoInicial()
        self.evaluarFitness()
        return (self.fitness)
    

    # Creamos el individuo que será nuestra solución
    def crearIndividuoInicial(self):

        import random
        random.seed(self.seed)
        
        p = self.almacen.numPedidos
        lista = range(0,p)
        rndm = random.sample(lista,p)
        self.individuoActualLista = rndm.copy()
        individuo = [[0,[]]]

        for i in rndm:
            
            agregado = False
            cantidadProductos = self.almacen.pedidosInfo.get(i)
            aux = 0
            while aux < len(individuo):
                if (cantidadProductos + individuo[aux][0]) < self.cap:
                    individuo[aux][0] += cantidadProductos
                    individuo[aux][1].append(i)
                    aux = len(individuo)
                    agregado = True
                aux += 1
            if agregado == False:
                individuo.append([cantidadProductos,[i]])

        self.individuo = individuo
    

    # Evaluar fitness con programación dinámica
    def evaluarFitness(self):
        
        from dinamica import Dinamica
        import copy
        dinam = Dinamica(self.almacen)

        fitness = 0

        for i in range(0,len(self.individuo)):
                
            ruta = copy.deepcopy(self.almacen.vacio)                
            aux = self.individuo[i][1]

            for k in range(0,len(aux)):
                coordenadas = self.almacen.coordenadasPedidos[self.individuo[i][1][k]]
                for c in coordenadas:
                    ruta[c[0]][c[1]] = 2
            dinam.alm.alm = copy.deepcopy(ruta)
            dinam.dinamica()
            fitness += dinam.tiempo

        self.fitness = fitness