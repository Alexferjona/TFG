class Tabu:

    def __init__(self,almacen, s, mostrarSolu):
        from datetime import datetime
        self.almacen = almacen

        #Cambiar la semilla por s si se quieren obtener experimentos reproducibles
        #self.seed = s
        self.seed = datetime.now()
        
        self.iteraciones = 50
        self.mostrarSolu = mostrarSolu


    def busquedaTabu(self):

        self.cap = self.almacen.capacidad
        self.numVecinos = self.almacen.numPedidos
        self.vecinos = []
        self.vecinosTuplas = []
        self.vecinosLista = []
        
        self.rutasCalculadas = {}


        self.iteracion = 0
        self.estructuraTabu = self.crearEstructuras()
        self.estructuraFrecuencias = self.crearEstructuras()
        self.keys = self.estructuraTabu.keys()
        self.individuoActual = self.crearIndividuoInicial()
        self.fitnessActual = self.evaluarFitness(self.individuoActual)

        

        self.mejorGlobal = [[0,[]]]
        self.mejorGlobalFitness = 10000000000000

        pararAux = 10000000000000
        parar = 0

        #Mostrar el print de abajo para ver los resultados de la primera iteración del algoritmo genético        
        #print("Iteración",self.iteracion,":","Mejor:",self.fitnessActual)


        while(self.iteracion < self.iteraciones and parar < 20):
            self.iteracion = self.iteracion + 1
            #print(i,self.fitnessActual)
            self.crearVecinos()
            self.evaluarVecinos()
            self.mejorVecino()
            self.actualizaciones()

            #Mostrar el print de abajo para ver los resultados de cada iteración del algoritmo genético        
            #print("Iteración",self.iteracion,":","Mejor:",self.fitnessActual)

            if(self.mejorGlobalFitness < pararAux):
                pararAux = self.mejorGlobalFitness
                parar = 0
            else:
                parar = parar + 1

        if(self.mostrarSolu == 1):
            self.solucion()
        
        return self.mejorGlobalFitness




    
    def crearEstructuras(self):

        estructura = {}

        numPed = self.almacen.numPedidos

        pedido = 1
        lista = range(0,numPed)
        for pedidoA in lista:
            for i in range(pedido,numPed):
                estructura[pedidoA,i] = 0
            pedido += 1
        return estructura



    
    def crearIndividuoInicial(self):

        import random
        random.seed(self.seed)
        
        p = self.almacen.numPedidos
        lista = range(0,p)
        rndm = random.sample(lista,p)
        self.individuoActualLista = rndm.copy()
        individuo = [[0,[]]]

        for i in rndm:
            
            agregado = False
            cantidadProductos = self.almacen.pedidosInfo.get(i)
            aux = 0
            while aux < len(individuo):
                if (cantidadProductos + individuo[aux][0]) < self.cap:
                    individuo[aux][0] += cantidadProductos
                    individuo[aux][1].append(i)
                    aux = len(individuo)
                    agregado = True
                aux += 1
            if agregado == False:
                individuo.append([cantidadProductos,[i]])

        return individuo

    

    def crearIndividuo(self, indi):
    
        self.individuoActualLista = indi.copy()
        individuo = [[0,[]]]

        for i in indi:
            
            agregado = False
            cantidadProductos = self.almacen.pedidosInfo.get(i)
            aux = 0
            while aux < len(individuo):
                if (cantidadProductos + individuo[aux][0]) < self.cap:
                    individuo[aux][0] += cantidadProductos
                    individuo[aux][1].append(i)
                    aux = len(individuo)
                    agregado = True
                aux += 1
            if agregado == False:
                individuo.append([cantidadProductos,[i]])

        return individuo
            
    

    # Evaluar fitness con programación dinámica
    def evaluarFitness(self, indi):
        
        from dinamica import Dinamica
        import copy
        dinam = Dinamica(self.almacen)

        fitness = 0

        for i in range(0,len(indi)):
                
            ruta = copy.deepcopy(self.almacen.vacio)                
            aux = indi[i][1]

            for k in range(0,len(aux)):
                coordenadas = self.almacen.coordenadasPedidos[indi[i][1][k]]
                for c in coordenadas:
                    ruta[c[0]][c[1]] = 2
            dinam.alm.alm = copy.deepcopy(ruta)
            dinam.dinamica()
            fitness += dinam.tiempo

        return fitness
    


    # Evaluar fitness con diccionario para ahorrar tiempo
    def evaluarFitnessHash(self, indi):
        
        from dinamica import Dinamica
        import copy
        dinam = Dinamica(self.almacen)

        fitness = 0


        for i in range(0,len(indi)):
                
            ruta = copy.deepcopy(self.almacen.vacio)                
            aux = indi[i][1]

            ordenado = sorted(aux)
            strings = [str(numero) for numero in ordenado]
            numerosString = "".join(strings)

            # Diccionario para guardar la información de las rutas ya calculadas y ahorrar tiempo
            if (numerosString not in self.rutasCalculadas.keys()):

                for k in range(0,len(aux)):
                    coordenadas = self.almacen.coordenadasPedidos[indi[i][1][k]]
                    for c in coordenadas:
                        ruta[c[0]][c[1]] = 2
                dinam.alm.alm = copy.deepcopy(ruta)
                dinam.dinamica()
                fitness += dinam.tiempo
                self.rutasCalculadas[numerosString] = dinam.tiempo

            else:
                fitness += self.rutasCalculadas.get(numerosString)

        return fitness

        


    def crearVecinos(self):

        actual = self.individuoActualLista
        self.vecinos = []
        self.vecinosTuplas = []

        for i in range(self.numVecinos):
            copia = actual.copy()
            aux = self.permutar2(copia)
            vecino =  aux[0]
            vecinoIndividuo = self.crearIndividuo(vecino)
            tupla = sorted(aux[1])
            if ((vecinoIndividuo not in self.vecinos and self.estructuraTabu[tupla[0],tupla[1]] == 0) or (vecinoIndividuo not in self.vecinos and self.evaluarFitness(vecinoIndividuo) < self.mejorGlobalFitness)):
                self.vecinos.append(vecinoIndividuo)
                self.vecinosTuplas.append((tupla,0))
                self.vecinosLista.append(vecino)
            else:
                i = i - 1
    

    # No funciona correctamente en problemas tan grandes, ya que las permutaciones al final se queda idénticas casi siempre
    def permutar(self, copia):

        import random

        aux = copia.copy()
        distinto = False
        a = random.randint(0,len(aux)-1)

        while(distinto == False):
            b = random.randint(0,len(aux)-1)
            if(a!=b):
                distinto = True

        x = aux[a]
        aux[a] = aux[b]
        aux[b] = x

        return (copia,(a,b))

    

    def permutar2(self, copia):
        
        import random

        copia = copia.copy()
        distinto = False
        punto = random.randint(0,len(copia)-1)
        while distinto == False:
            hasta = random.randint(2,len(copia))
            if (hasta-1)!= punto:
                #print(punto,hasta)
                distinto = True

        aux = copia[punto:(punto+hasta)]
        aux.reverse()            
        inversa = copia[0:punto] + aux + copia[(punto+hasta):(len(copia))]

        #print(copia,inversa)
        return (inversa,(punto,hasta-1))



    def evaluarVecinos(self):

        for i in range(0,len(self.vecinos)):
        
            fitnessVecino = self.evaluarFitness(self.vecinos[i])
            self.vecinosTuplas[i] = (self.vecinosTuplas[i][0],fitnessVecino)

        
    
    def mejorVecino(self):

        aux = 100000000000
        auxF = 0
        
        for i in range(len(self.vecinosTuplas)):
            if (self.vecinosTuplas[i][1] < aux):
                auxF = self.vecinosTuplas[i][1]
                aux = i

        if(auxF < self.mejorGlobalFitness):
            self.mejorGlobalFitness = auxF
            self.mejorGlobal = self.vecinos[aux]
                 
        self.mejor = aux
        self.mejorFitness = auxF
        

    

    def actualizaciones(self):

        self.individuoActual = self.vecinos[self.mejor]
        self.fitnessActual = self.mejorFitness
        self.individuoActualLista = self.vecinosLista[self.mejor]
        
        for key in self.keys:
            valor = self.estructuraTabu[key]
            if (valor > 0):
                self.estructuraTabu[key] = self.estructuraTabu[key] - 1

        aux = sorted(self.vecinosTuplas[self.mejor][0])
        self.estructuraTabu[aux[0],aux[1]] = 3


    # Método que muestra de forma gráfica la solución, utilizando la interfaz implementada.
    def solucion(self):

        from dinamica import Dinamica
        import copy

        solucionMostrar = Dinamica(self.almacen)
        rutas = self.individuoActual
        for i in range(0,len(rutas)):
            ruta = copy.deepcopy(self.almacen.vacio)
            for j in range(0,len(rutas[i][1])):
                coord = self.almacen.coordenadasPedidos[rutas[i][1][j]]
                for c in range(0,len(coord)):
                    ruta[coord[c][0]][coord[c][1]] = 2+c # cambiar colores segun pedido
            solucionMostrar.alm.alm = copy.deepcopy(ruta)
            solucionMostrar.dinamica()
            self.almacen.pedidosMostrar = rutas[i][1]
            self.almacen.crear(solucionMostrar.camino, i)