def main():

    from almacen2 import Almacen
    from dinamica import Dinamica
    from genetico import Genetico
    from tabu import Tabu
    import copy
    import time

    print("\n\n######################################################################################")
    print("####                                                                              ####")
    print("####    Algoritmos heurísticos para problemas de recogida de pedidos en tienda    ####")
    print("####               Trabajo fin de grado Alejandro Fernández Arjona                ####")
    print("####                                                                              ####")
    print("######################################################################################")


    Instancias = ["29s-40-30-0.txt","30s-40-45-0.txt","31s-40-60-0.txt","32s-40-75-0.txt", "37s-60-30-0.txt","38s-60-45-0.txt","39s-60-60-0.txt","40s-60-75-0.txt", "61s-80-30-0.txt","62s-80-45-0.txt","63s-80-60-0.txt","64s-80-75-0.txt", "69s-100-30-0.txt","70s-100-45-0.txt","71s-100-60-0.txt","72s-100-75-0.txt"]
    Settings = ["sett29.txt","sett30.txt","sett31.txt","sett32.txt","sett37.txt","sett38.txt","sett39.txt","sett40.txt","sett61.txt","sett62.txt","sett63.txt","sett64.txt","sett69.txt","sett70.txt","sett71.txt","sett72.txt"]


    parar = False
    while(parar == False):
        batch = input("\n\nEscribe el ''Genetico'' o ''Tabu'' para elegir un método de resolución para el batching.\n")
        if (batch == 'Genetico' or batch == 'Tabu'):
            parar = True
    
    parar2 = False
    while(parar2 == False):
        interf = input("\n\n¿Quieres observar la solución con la interfaz gráfica? Escribe ''Si'' o ''No''\n")
        if (interf== 'Si' or interf == 'No'):
            parar2 = True

    parar3 = False
    instancias2 = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]
    while(parar3 == False):
        inst = input("\n\nEscribe un número del 1 al 16 para seleccionar la instancia de pedidos a resolver\n")
        if (int(inst) in instancias2):
            parar3 = True

    tiempo = time.time()

    if(batch=="Genetico"):
        almacen = Almacen("InstanciasBien/"+Settings[int(inst)-1], "InstanciasBien/"+Instancias[int(inst)-1])
        almacen.leerInstancia()
        almacen.crearPedidos()

        print("\n\nAlgoritmo Genético:\n")
        almacen.alm = copy.deepcopy(almacen.vacio)
        if(interf=="Si"):
            genetico = Genetico(almacen,1,1)
        else:
            genetico = Genetico(almacen,1,0)
        solucion = genetico.genetico()

    if(batch=="Tabu"):
        almacen = Almacen("InstanciasBien/"+Settings[int(inst)-1], "InstanciasBien/"+Instancias[int(inst)-1])
        almacen.leerInstancia()
        almacen.crearPedidos()

        print("\n\nBúsqueda Tabú:\n")
        almacen.alm = copy.deepcopy(almacen.vacio)
        if(interf=="Si"):
            tabu = Tabu(almacen,1,1)
        else:
            tabu = Tabu(almacen,1,0)
        solucion = tabu.busquedaTabu()

    print("\nSolución:",solucion,"\n\n")
    print("\nTiempo de ejecución:", round(time.time()-tiempo,2),"segundos")
    print("\n")

main()

